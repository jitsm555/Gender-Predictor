# Gender-Precdictor
Gender identifier is a classifier which detect names gender by analyzing sample text.
